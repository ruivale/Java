package parsing;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c)
 * Company:
 * @author
 * @version 1.0
 */


import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXParseException;
import org.xml.sax.SAXException;
/**
* A demo implementation of the org.xml.sax.ErrorHandler class.
*/
public class DemoErrorHandler implements ErrorHandler {
  public void warning( SAXParseException exception ) {
    System.out.println("--- WARNING ---");
    System.out.println("\tLine number:\t" + exception.getLineNumber());
    System.out.println("\tColumn number:\t" + exception.getColumnNumber());
    System.out.println("\tMessage:\t" + exception.getMessage());
    System.out.println("---------------\n");
  }
  public void error( SAXParseException exception ) {
    System.out.println("--- ERROR ---");
    System.out.println("\tLine number:\t" + exception.getLineNumber());
    System.out.println("\tColumn number:\t" + exception.getColumnNumber());
    System.out.println("\tMessage:\t" + exception.getMessage());
    System.out.println("-------------\n");
  }
  public void fatalError( SAXParseException exception ) throws SAXException {
    System.out.println("--- FATAL ERROR ---");
    System.out.println("\tLine number:\t" + exception.getLineNumber());
    System.out.println("\tColumn number:\t" + exception.getColumnNumber());
    System.out.println("\tMessage:\t" + exception.getMessage());
    System.out.println("-------------------\n");
    throw new SAXException("Fatal Error encountered � parsing terminated.");
  }
}
