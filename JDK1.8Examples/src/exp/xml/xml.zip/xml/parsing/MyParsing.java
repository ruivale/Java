package parsing;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c)
 * Company:
 * @author
 * @version 1.0
 */

import java.io.*;

import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

import org.apache.xerces.parsers.SAXParser;


public class MyParsing {

  public MyParsing(String filename) {

    try{

      XMLReader parser = new SAXParser();
      parser.parse(filename);

    }catch(IOException ioe){
      System.out.println("ERROR: "+ioe.getMessage());
    }catch(SAXException saxe){
      System.out.println("ERROR: "+saxe.getMessage());
    }

  }
  public static void main(String[] args) {
    MyParsing myParsing1 = new MyParsing(args[0]/*file name*/);
  }
}