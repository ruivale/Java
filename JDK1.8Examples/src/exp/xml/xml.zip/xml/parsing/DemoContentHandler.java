package parsing;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c)
 * Company:
 * @author
 * @version 1.0
 */
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
/**
* A demo implementation of the org.xml.sax.ContentHandler class.
*/
public class DemoContentHandler implements ContentHandler {
  // The locator provides the location of a callback within a document
  private Locator locator;
  public void setDocumentLocator( Locator locator ) {
    //System.out.println("setDocumentLocator called");
    // store the locator:
    this.locator = locator;
  }
  public void startDocument() throws SAXException {
    System.out.println("*** The beginning of parsing!");
  }
  public void endDocument() throws SAXException {
    System.out.println("*** The end of parsing!");
  }
  public void processingInstruction( String target, String instruction )
  throws SAXException {
    //System.out.println("PI - Target:" + target + " Instruction:" + instruction);
  }

  public void startPrefixMapping( String prefix, String uri ) {
    //System.out.println("Start mapping - Prefix:" + prefix + " URI:" + uri);
  }

  public void endPrefixMapping( String prefix ) {
    //System.out.println("End mapping - Prefix:" + prefix);
  }

  public void startElement( String namespaceURI, String localName,
                            String fullName, Attributes attributes )
  throws SAXException {
    System.out.println("\nStart element - Name: " + localName);
    if ( !namespaceURI.equals("") ) {
      System.out.println("\tIs in namespace, full name: " + fullName);
    }
    // Print the attributes:
    for ( int i = 0; i < attributes.getLength(); i++ ) {

      System.out.println("\tAttribute - Name:" + attributes.getLocalName(i)
                         + " Value:" + attributes.getValue(i));
    }
  }
  public void endElement( String namespaceURI, String localName,
                          String fullName )
  throws SAXException {
    System.out.println("End element - Name: " + localName);
    if ( !namespaceURI.equals("") ) {
      System.out.println("\tIs in namespace, full name: " + fullName);
    }
  }
  public void characters( char[] chars, int start, int end )
  throws SAXException {
    String str = new String( chars, start, end );
    System.out.println("\tCharacters: " + str);
  }
  public void ignorableWhitespace( char[] chars, int start, int end )
  throws SAXException {
    //String whitespace = new String( chars,start,end );
    //System.out.println("Ignorable whitespace: \"" + whitespace + "\"");
  }

  public void skippedEntity( String name ) throws SAXException {
    //System.out.println("Skipped entity: " + name);
  }

}
